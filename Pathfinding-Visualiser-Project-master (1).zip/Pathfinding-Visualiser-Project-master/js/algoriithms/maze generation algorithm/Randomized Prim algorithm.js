/**
 * @author Karan Gandhi
 * @email karangandhi.programming@gmail.com
*/
"use strict";
function primsRandomAlgorithm(animationTime) {
	let v = [];

}
